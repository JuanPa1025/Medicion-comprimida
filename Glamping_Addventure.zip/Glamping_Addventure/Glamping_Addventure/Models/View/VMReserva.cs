﻿namespace Glamping_Addventure.Models.View
{
    public class VMReserva
    {
        public string FechaReserva { get; set; }
        public int Cantidad { get; set; }
    }
}
